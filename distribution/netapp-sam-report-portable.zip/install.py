import argparse
import json
from pathlib import Path
import shutil
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from portable_common import plain_path, verify_skill


def install(agent, skills_directory, apply=False):
    verify_skill(ROOT)
    if not Path(skills_directory).is_absolute():
        raise ValueError('Select an absolute skills directory explicitly')
    parent = plain_path(skills_directory)
    target = parent / 'netapp-sam-report-portable'
    if target.exists() or target.is_symlink():
        raise FileExistsError('Refusing to replace any existing Skill: ' + str(target))
    if parent == ROOT or ROOT in parent.parents:
        raise ValueError('Cannot install inside the distribution itself')
    result = {'agent': agent, 'destination': str(target), 'applied': False,
              'existing_skills_modified': False, 'client_ui_verified': False}
    if apply:
        parent.mkdir(parents=True, exist_ok=True)
        staging = Path(tempfile.mkdtemp(prefix='.sam-install-', dir=parent))
        try:
            shutil.copytree(ROOT, staging, dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            verify_skill(staging)
            if target.exists():
                raise FileExistsError('Target appeared during install')
            staging.rename(target)
        finally:
            if staging.exists():
                if plain_path(staging).parent != parent:
                    raise ValueError('Temporary installation path left the selected directory')
                shutil.rmtree(staging)
        result['applied'] = True
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Non-overwriting local Skill installer; defaults to preview only')
    parser.add_argument('--agent', required=True, choices=('codex', 'workbuddy', 'trae'))
    parser.add_argument('--skills-dir', required=True, type=Path)
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    print(json.dumps(install(args.agent, args.skills_dir, args.apply), ensure_ascii=False, indent=2))
