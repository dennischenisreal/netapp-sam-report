import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def plain_path(path):
    path = Path(path).absolute()
    for part in (path, *path.parents):
        if part.is_symlink() or part.is_junction():
            raise ValueError('Linked paths are not allowed: ' + str(part))
    return path.resolve()


def relative_name(name):
    value = PurePosixPath(name)
    if not name or '\\' in name or ':' in name or value.is_absolute() or any(
            part in ('', '.', '..') for part in name.split('/')) or value.as_posix() != name:
        raise ValueError('Unsafe archive path')
    reserved = {'con', 'prn', 'aux', 'nul'} | {
        prefix + str(number) for prefix in ('com', 'lpt') for number in range(1, 10)}
    if any(part.endswith((' ', '.')) or part.split('.')[0].lower() in reserved for part in value.parts):
        raise ValueError('Unsafe Windows archive path')
    return value


def verify_skill(root):
    root = plain_path(root)
    manifest = json.loads((root / 'distribution-manifest.json').read_text(encoding='utf-8'))
    seen = set()
    for entry in manifest['files']:
        name = relative_name(entry['path']).as_posix()
        if name.casefold() in seen:
            raise ValueError('Duplicate distribution file')
        seen.add(name.casefold())
        source = plain_path(root / name)
        source.relative_to(root)
        if source.stat().st_size != entry['bytes'] or digest(source) != entry['sha256']:
            raise ValueError('Distribution checksum mismatch: ' + name)
    expected = {entry['path'] for entry in manifest['files']} | {'distribution-manifest.json'}
    observed = {path.relative_to(root).as_posix() for path in root.rglob('*')
                if path.is_file() and '__pycache__' not in path.parts}
    if observed != expected:
        raise ValueError('Unexpected or missing distribution files')
    return manifest


def extract_runtime(archive, destination):
    destination = plain_path(destination)
    if destination.exists():
        raise FileExistsError('Runtime destination already exists')
    with zipfile.ZipFile(archive) as stream:
        entries = stream.infolist()
        names = [relative_name(entry.filename).as_posix() for entry in entries]
        if len(names) != len({name.casefold() for name in names}):
            raise ValueError('Duplicate runtime entry')
        if sum(entry.file_size for entry in entries) > 100 * 1024 * 1024:
            raise ValueError('Runtime archive too large')
        for entry in entries:
            mode = entry.external_attr >> 16
            if stat.S_ISLNK(mode) or entry.is_dir() or entry.file_size > 20 * 1024 * 1024:
                raise ValueError('Unsupported runtime entry')
        manifest = json.loads(stream.read('package-manifest.json').decode('utf-8'))
        expected = {entry['path'] for entry in manifest['files']} | {'package-manifest.json'}
        if set(names) != expected or len(manifest['files']) != len(expected) - 1:
            raise ValueError('Runtime inventory mismatch')
        for entry in manifest['files']:
            data = stream.read(entry['path'])
            if len(data) != entry['bytes'] or hashlib.sha256(data).hexdigest() != entry['sha256']:
                raise ValueError('Runtime checksum mismatch')
        destination.mkdir(parents=True)
        for name in names:
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as output:
                output.write(stream.read(name))
