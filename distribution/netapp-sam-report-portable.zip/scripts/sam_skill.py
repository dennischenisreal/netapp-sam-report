import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from portable_common import digest, extract_runtime, plain_path, verify_skill


def external(path):
    if not Path(path).is_absolute():
        raise ValueError('Use explicit absolute paths')
    result = plain_path(path)
    if result == ROOT or ROOT in result.parents:
        raise ValueError('Customer files and workspace must be outside the installed Skill')
    return result


def environment(project):
    result = {key: value for key, value in os.environ.items()
              if not key.startswith(('SAM_', 'PYTHON'))}
    result.update(SAM_PROJECT_ROOT=str(project),
                  SAM_PROJECT_CONFIG=str(project / '.local/config/project.json'),
                  SAM_SHARED_SKILL_DIR=str(project / '.local/runtime/skills/NetApp-SAM-Report'),
                  PYTHONIOENCODING='utf-8', PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
    return result


def execute(project, *arguments):
    subprocess.run([sys.executable, '-B', *map(str, arguments)], cwd=project,
                   env=environment(project), check=True)


def setup(args):
    manifest = verify_skill(ROOT)
    workspace = external(args.workspace)
    logs, knowledge, reports, profiles = map(external, (args.logs, args.knowledge, args.reports, args.profiles))
    history = [external(value) for value in args.history]
    for path in (logs, knowledge, *history):
        if not path.is_dir():
            raise NotADirectoryError(path)
    if not profiles.is_file():
        raise FileNotFoundError(profiles)
    private_rules = json.loads(profiles.read_text(encoding='utf-8-sig'))
    for path in (logs, knowledge, reports, profiles, *history):
        if path == workspace or workspace in path.parents or path in workspace.parents:
            raise ValueError('Inputs and outputs must be outside the new runtime workspace')
    inputs = (logs, knowledge, *history)
    for index, source in enumerate(inputs):
        for other in inputs[index + 1:]:
            if source == other or source in other.parents or other in source.parents:
                raise ValueError('Input directories must not overlap')
    for source in (logs, knowledge, *history):
        if source == reports or source in reports.parents or reports in source.parents:
            raise ValueError('Report output must be separate from input directories')
    seven_zip = args.seven_zip or shutil.which('7z') or (
        Path(os.environ.get('ProgramFiles', 'C:/Program Files')) / '7-Zip/7z.exe')
    seven_zip = plain_path(seven_zip)
    if not seven_zip.is_file():
        raise FileNotFoundError('7-Zip CLI is required; install it or specify --seven-zip explicitly')
    if workspace.exists():
        raise FileExistsError('Use a new workspace; existing setup is never overwritten')
    workspace.mkdir(parents=True)
    project = workspace / 'runtime'
    extract_runtime(ROOT / 'assets/runtime.zip', project)
    execute(project, project / 'tools/candidate_runtime.py', 'install')
    config_path = project / '.local/config/project.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config.update(logs_root=str(logs), knowledge_root=str(knowledge), reports_root=str(reports),
                  history_roots=list(map(str, history)), trend_output_root=str(workspace / 'trends'),
                  seven_zip_path=str(seven_zip))
    shared = project / '.local/runtime/skills/NetApp-SAM-Report'
    sys.path.insert(0, str(shared))
    from customer_profiles import _validate
    _validate(private_rules)
    config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding='utf-8')
    (config_path.parent / 'customer-profiles.local.json').write_text(
        json.dumps(private_rules, ensure_ascii=False, indent=2), encoding='utf-8')
    execute(project, project / 'tools/candidate_runtime.py', 'doctor')
    receipt = {'schema_version': 1, 'runtime_archive_sha256': digest(ROOT / 'assets/runtime.zip'),
               'source_commit': manifest['source_commit'], 'python': sys.executable,
               'config_sha256': digest(config_path),
               'profiles_sha256': digest(config_path.parent / 'customer-profiles.local.json')}
    (workspace / 'setup.json').write_text(json.dumps(receipt, indent=2), encoding='utf-8')
    print(json.dumps({'status': 'ready', 'workspace': str(workspace)}, ensure_ascii=False))


def selected_project(workspace):
    verify_skill(ROOT)
    workspace = external(workspace)
    receipt = json.loads((workspace / 'setup.json').read_text(encoding='utf-8'))
    if receipt['runtime_archive_sha256'] != digest(ROOT / 'assets/runtime.zip'):
        raise ValueError('Workspace belongs to another package; use a new workspace')
    if Path(receipt['python']).resolve() != Path(sys.executable).resolve():
        raise ValueError('Use the Python environment recorded during setup')
    project = plain_path(workspace / 'runtime')
    for name, field in [('project.json', 'config_sha256'),
                        ('customer-profiles.local.json', 'profiles_sha256')]:
        if digest(project / '.local/config' / name) != receipt[field]:
            raise ValueError('Configuration changed; review and set up a new workspace')
    return project


def report(args):
    project = selected_project(args.workspace)
    config = json.loads((project / '.local/config/project.json').read_text(encoding='utf-8'))
    source = external(args.input)
    source.relative_to(Path(config['logs_root']).resolve())
    if not source.is_dir():
        raise NotADirectoryError(source)
    execute(project, project / 'tools/candidate_runtime.py', 'doctor')
    execute(project, ROOT / 'scripts/sam_skill.py', '_report', '--workspace', args.workspace,
            '--input', source, *(['--custom-thresholds'] if args.custom_thresholds else []))


def internal_report(args):
    project = selected_project(args.workspace)
    clean = environment(project)
    os.environ.clear()
    os.environ.update(clean)
    shared = project / '.local/runtime/skills/NetApp-SAM-Report'
    sys.path.insert(0, str(shared))
    spec = importlib.util.spec_from_file_location('portable_sam_entry', shared / 'run.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    config = json.loads((project / '.local/config/project.json').read_text(encoding='utf-8'))
    source = external(args.input)
    source.relative_to(Path(config['logs_root']).resolve())
    if not source.is_dir():
        raise NotADirectoryError(source)
    output = module.process_directory(str(source), config['reports_root'],
                                      not args.custom_thresholds, runs_root=str(project / '.local/runs'))
    print(json.dumps({'report': output, 'defaults': not args.custom_thresholds}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description='Portable SAM Skill: setup, doctor, test and report')
    commands = parser.add_subparsers(dest='command', required=True)
    initialize = commands.add_parser('setup')
    initialize.add_argument('--workspace', required=True, type=Path)
    for name in ('logs', 'knowledge', 'reports', 'profiles'):
        initialize.add_argument('--' + name, required=True, type=Path)
    initialize.add_argument('--history', action='append', type=Path, default=[])
    initialize.add_argument('--seven-zip', type=Path)
    for name in ('doctor', 'test', 'report', '_report'):
        command = commands.add_parser(name)
        command.add_argument('--workspace', required=True, type=Path)
        if name in ('report', '_report'):
            command.add_argument('--input', required=True, type=Path)
            command.add_argument('--custom-thresholds', action='store_true')
    args = parser.parse_args()
    if args.command == 'setup':
        setup(args)
    elif args.command == 'report':
        report(args)
    elif args.command == '_report':
        internal_report(args)
    else:
        project = selected_project(args.workspace)
        execute(project, project / 'tools/candidate_runtime.py', args.command)


if __name__ == '__main__':
    main()
